// بيانات الحسابات
let users = [];
let currentUser = null;
let accounts = [];

// وظائف عرض النماذج
function showRegister() {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("register-form").classList.remove("hidden");
}

function showLogin() {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("login-form").classList.remove("hidden");
}

function goBack() {
    document.getElementById("register-form").classList.add("hidden");
    document.getElementById("login-form").classList.add("hidden");
    document.getElementById("auth-section").classList.remove("hidden");
}

// إنشاء حساب
function register() {
    const name = document.getElementById("reg-name").value;
    const email = document.getElementById("reg-email").value;
    const phone = document.getElementById("reg-phone").value;
    const password = document.getElementById("reg-password").value;

    users.push({ name, email, phone, password, balance: 0 });
    alert("تم إنشاء الحساب بنجاح!");
    goBack();
}

// تسجيل الدخول
function login() {
    const identifier = document.getElementById("login-identifier").value;
    const password = document.getElementById("login-password").value;

    const user = users.find(
        u => (u.email === identifier || u.phone === identifier) && u.password === password
    );

    if (user) {
        currentUser = user;
        document.getElementById("login-form").classList.add("hidden");
        document.getElementById("dashboard").classList.remove("hidden");
        document.getElementById("user-name").innerText = user.name;
        document.getElementById("user-balance").innerText = user.balance;
        fetchExchangeRate();
    } else {
        alert("بيانات تسجيل الدخول غير صحيحة!");
    }
}

// تسجيل الخروج
function logout() {
    currentUser = null;
    document.getElementById("dashboard").classList.add("hidden");
    document.getElementById("auth-section").classList.remove("hidden");
}

// إضافة حساب بنكي أو محفظة
function addAccount() {
    const account = document.getElementById("bank-account").value;
    if (account) {
        accounts.push(account);
        alert("تمت إضافة الحساب بنجاح!");
        document.getElementById("bank-account").value = "";
    } else {
        alert("يرجى إدخال رقم حساب صحيح.");
    }
}

// جلب سعر الصرف
async function fetchExchangeRate() {
    try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/SDG');
        const data = await response.json();
        const rate = data.rates.EGP; // تحويل من جنيه سوداني إلى مصري
        document.getElementById("exchange-rate").innerText = rate.toFixed(2);
    } catch (error) {
        console.error("خطأ في جلب سعر الصرف:", error);
        document.getElementById("exchange-rate").innerText = "تعذر الجلب";
    }
}

// إجراء التحويل
function performTransfer() {
    const recipient = document.getElementById("recipient").value;
    const method = document.getElementById("transfer-method").value;
    const amount = parseFloat(document.getElementById("transfer-amount").value);

    if (currentUser.balance >= amount && amount > 0) {
        currentUser.balance -= amount;
        document.getElementById("user-balance").innerText = currentUser.balance;
        alert(تم التحويل بنجاح إلى ${recipient} عبر ${method === "vodafone" ? "فودافون كاش" : "الحساب البنكي"});
    } else {
        alert("الرصيد غير كافٍ أو مبلغ غير صالح.");
    }
}